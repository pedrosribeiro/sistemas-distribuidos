from app.ms_itinerarios.consumer import start_consuming

if __name__ == "__main__":
    start_consuming()
